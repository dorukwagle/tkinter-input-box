import setuptools


setuptools.setup(
    name="tkinter-input-box",
    version="1.0.1",
    long_description="Please refer to the following github link for documentation and examples:\n "
                     "https://github.com/dorukwagle/tkinter-input-box",
    packages=setuptools.find_packages()
)
